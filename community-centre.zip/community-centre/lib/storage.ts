import "server-only";
import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";
import { getStore, type Store } from "@netlify/blobs";
import { SiteContent, withDefaults } from "@/lib/content";

/**
 * Content is one JSON file, and photos are stored alongside it.
 * - On Netlify: saved in Netlify Blobs, which is built in and needs no setup.
 *   Photos are served from /media/<name>.
 * - Locally: saved in data/content.json, with photos in public/uploads.
 */

const CONTENT_KEY = "content.json";
const localFile = path.join(process.cwd(), "data", "content.json");

function blobStore(): Store | null {
  try {
    return getStore({ name: "site", consistency: "strong" });
  } catch {
    // Not running on Netlify (no Blobs environment available).
    return null;
  }
}

/** Never let a slow storage response hang the page. */
function withTimeout<T>(promise: Promise<T>, ms = 8000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error(`Storage timed out after ${ms}ms`)), ms)),
  ]);
}

function requireStoreInProduction(): Store | null {
  const store = blobStore();
  if (!store && process.env.NODE_ENV === "production" && !process.env.ALLOW_LOCAL_STORAGE) {
    throw new Error("Netlify Blobs isn't available. Deploy on Netlify, or set ALLOW_LOCAL_STORAGE=1 when self-hosting.");
  }
  return store;
}

export async function getContent(): Promise<SiteContent> {
  try {
    const store = blobStore();
    if (store) {
      // Check the file exists first: before the first save there's nothing to read.
      const { blobs } = await withTimeout(store.list({ prefix: CONTENT_KEY }));
      if (!blobs.some((b) => b.key === CONTENT_KEY)) return withDefaults(null);
      return withDefaults(await withTimeout(store.get(CONTENT_KEY, { type: "json" })));
    }
    const raw = await fs.readFile(localFile, "utf8");
    return withDefaults(JSON.parse(raw));
  } catch (err: any) {
    if (err?.code !== "ENOENT") console.error("Could not load content, using defaults:", err);
    return withDefaults(null);
  }
}

export async function saveContent(content: SiteContent): Promise<void> {
  const store = requireStoreInProduction();
  if (store) {
    await store.setJSON(CONTENT_KEY, content);
    return;
  }
  await fs.mkdir(path.dirname(localFile), { recursive: true });
  await fs.writeFile(localFile, JSON.stringify(content, null, 2), "utf8");
}

const IMAGE_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/avif": "avif",
};
export const IMAGE_NAME = /^[0-9]+-[a-f0-9]{12}\.(jpg|png|webp|avif)$/;
export const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;

export async function saveImage(file: File): Promise<string> {
  const ext = IMAGE_TYPES[file.type];
  if (!ext) throw new Error("Please upload a JPG, PNG, WebP or AVIF image.");
  if (file.size > MAX_UPLOAD_BYTES) throw new Error("Images must be under 4 MB.");
  const name = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}.${ext}`;
  const data = await file.arrayBuffer();

  const store = requireStoreInProduction();
  if (store) {
    await store.set(`images/${name}`, data, { metadata: { contentType: file.type } });
    return `/media/${name}`;
  }
  const dir = path.join(process.cwd(), "public", "uploads");
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, name), Buffer.from(data));
  return `/uploads/${name}`;
}

export async function readImage(name: string): Promise<{ data: ArrayBuffer; contentType: string } | null> {
  if (!IMAGE_NAME.test(name)) return null;
  const store = blobStore();
  if (!store) return null;
  const result = await withTimeout(store.getWithMetadata(`images/${name}`, { type: "arrayBuffer" }));
  if (!result) return null;
  const contentType = String(result.metadata?.contentType ?? "");
  return { data: result.data, contentType: Object.keys(IMAGE_TYPES).includes(contentType) ? contentType : "application/octet-stream" };
}
