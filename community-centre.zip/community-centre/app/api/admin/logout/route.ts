import { NextResponse } from "next/server";
import { clearSession, sameOrigin } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  await clearSession();
  return NextResponse.redirect(new URL("/admin/login", req.url), 303);
}
