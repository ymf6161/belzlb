import { NextResponse } from "next/server";
import { createSessionCookie, verifyLoginToken } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const email = await verifyLoginToken(url.searchParams.get("token") ?? "");
  if (!email) return NextResponse.redirect(new URL("/admin/login?error=expired", url), 303);
  await createSessionCookie(email);
  return NextResponse.redirect(new URL("/admin", url), 303);
}
